package com.example.test

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import com.example.iwillfindmyage.R;

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainactivity)
        val edtBirthDate = findViewById<EditText>(R.id.edtBirthDate)
        val tvAge = findViewById<TextView>(R.id.tvAge)
        val btnGetAge = findViewById<Button>(R.id.btnGetAge)

        btnGetAge.setOnClickListener { v: View? ->
            val birthDateStr = edtBirthDate.text.toString()
            if (!birthDateStr.isEmpty()) {
                try {
                    val sdf = SimpleDateFormat("dd/MM/yyyy")
                    sdf.isLenient = false
                    val birthDate = sdf.parse(birthDateStr)

                    val today = Calendar.getInstance()
                    val currentYear = today[Calendar.YEAR]
                    val currentMonth = today[Calendar.MONTH] + 1
                    val currentDay = today[Calendar.DAY_OF_MONTH]

                    val birth = Calendar.getInstance()
                    birth.time = birthDate
                    val birthYear = birth[Calendar.YEAR]
                    val birthMonth = birth[Calendar.MONTH] + 1
                    val birthDay = birth[Calendar.DAY_OF_MONTH]

                    var age = currentYear - birthYear
                    if (currentMonth < birthMonth || (currentMonth == birthMonth && currentDay < birthDay)) {
                        age--
                    }

                    tvAge.text = "Your age is: $age"
                } catch (e: ParseException) {
                    tvAge.text = "Invalid date format! Use dd/MM/yyyy."
                }
            } else {
                tvAge.text = "Please enter your birth date!"
            }
        }
    }
}